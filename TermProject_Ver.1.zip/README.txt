사용방법

1. 두번째 아이콘 ( Data import ) 클릭해서 STL 파일 import
   1.1. Utal_teapot_(solid).stl import
   1.2. part1~part7.stl 중 택 1하여 import

2. s 키 입력 시, 시작
   2.1. s 키 재 입력시 멈춤 (toggle키)

멈춤 상태에서
- 마우스 좌우클릭후 드래그 : 시점변환
- 마우스 휠클릭후 드래그 : 시점이동