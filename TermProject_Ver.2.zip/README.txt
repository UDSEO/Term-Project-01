사용방법

1. 두번째 아이콘 ( Data import ) 클릭해서 STL 파일 import
   1.1. Utal_teapot_(solid).stl import
   1.2. part1~part7.stl 중 택 1하여 import

2. s 키 입력 시, 시작
   2.1. s 키 재 입력시 멈춤 (toggle키)

멈춤 상태에서
- 마우스 좌우클릭후 드래그 : 시점변환
- 마우스 휠클릭후 드래그 : 시점이동

3. 숫자1키 입력시 Utah_teapot 가시화 변경 (mesh <-> point cloud)
   숫자2키 입력시 part 가시화 변경 (mesh <-> point cloud)


발표 때 누락된 내용
공간을 voxel로 나누어 elitism을 적용하다보니 한 voxel에 할당되는 pop_size가
줄어들어, 정답 위치를 찾은 이후 값이 threshold 이하로 수렴하는데 시간이 많이 걸립니다.
그래서 ppt 마지막 페이지에 모듈화를 통해 개선전후를 섞어 사용하는 방법을 제시하였습니다.
